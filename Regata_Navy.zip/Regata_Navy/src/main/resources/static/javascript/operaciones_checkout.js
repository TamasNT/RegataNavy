
function checkout_paso_0() {
	$("#contenedor").html(html_checkout_1);
	$("#aceptar_paso_1").click(checkout_paso_1_aceptar);
	$("#show-all-container").hide();
}

function checkout_paso_1_aceptar() {
	let nombre = $("#campo_nombre").val();
	let direccion = $("#campo_direccion").val();
	let provincia = $("#campo_provincia").val();

	if (!nombre || !direccion || !provincia) {
		Toast.fire({
			icon: "error",
			title: "Por favor, complete todos los campos"
		});
		return;
	}

	$.post("realizar-pedido-paso1", {
		nombre: nombre,
		direccion: direccion,
		provincia: provincia
	}).done(function(res) {
		if (res == "ok") {
			$("#contenedor").html(html_checkout_2);
			$("#aceptar_paso_2").click(checkout_paso_2_aceptar);
		} else {
			alert(res);
		}
	});
}

function checkout_paso_2_aceptar() {
	let tipo_tarjeta = $("#tipo_tarjeta").val();
	let numero_tarjeta = $("#numero_tarjeta").val();
	let titular_tarjeta = $("#titular_tarjeta").val();

	if (!tipo_tarjeta || !numero_tarjeta || !titular_tarjeta) {
		Toast.fire({
			icon: "error",
			title: "Por favor, complete todos los campos"
		});
		return;
	}

	$.post("realizar-pedido-paso2", {
		tarjeta: tipo_tarjeta,
		numero: numero_tarjeta,
		titular: titular_tarjeta
	}).done(function(res) {
		console.log("Resumen del pedido:", res);

		let total = 0;
		if (res.yates && Array.isArray(res.yates)) {
			total = res.yates.reduce((sum, item) => sum + parseFloat(item.precio), 0);
		}

		// Renderizar el template de checkout paso 3 y actualizar el total en el DOM
		let html = Mustache.render(html_checkout_3, { ...res, total: total.toFixed(2) });
		$("#contenedor").html(html);

		// Actualizar el elemento total en el DOM
		$("#total").text(`$${total.toFixed(2)}`);

		// Agregar el evento para confirmar el pedido
		$("#boton_confirmar_pedido").click(confirmar_pedido);
	});
}

function confirmar_pedido() {
	$.post("confirmar-pedido").done(function(res) {
		if (res == "pedido completado") {
			Toast.fire({
				icon: "success",
				title: "Gracias por realizar tu pedido"
			});
			cargarListadoYates();
		}
	});
}

// Iniciar el proceso de checkout
$(document).ready(function() {
	checkout_paso_0();
});