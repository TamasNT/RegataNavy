let html_carrito = "";
let html_checkout_1 = "";
let html_checkout_2 = "";
let html_checkout_3 = "";
let html_detalles_yate = "";
let html_footer = "";
let html_header = "";
let html_listado_yates = "";
let html_registro_usuario = "";


$.get("plantillas" + sufijo_idioma + "/carrito.html").done(function(res) {
	html_carrito = res;
});
$.get("plantillas" + sufijo_idioma + "/checkout_1.html").done(function(res) {
	html_checkout_1 = res;
});
$.get("plantillas" + sufijo_idioma + "/checkout_2.html").done(function(res) {
	html_checkout_2 = res;
});
$.get("plantillas" + sufijo_idioma + "/checkout_3.html").done(function(res) {
	html_checkout_3 = res;
});
$.get("plantillas" + sufijo_idioma + "/detalles_yate.html").done(function(res) {
	html_detalles_yate = res;
});
$.get("plantillas" + sufijo_idioma + "/footer.html").done(function(res) {
	html_footer = res;
});
$.get("plantillas" + sufijo_idioma + "/header.html").done(function(res) {
	html_header = res;
});
$.get("plantillas" + sufijo_idioma + "/listado_yates.html").done(function(res) {
	html_listado_yates = res;
});
$.get("plantillas" + sufijo_idioma + "/registro_usuario.html").done(function(res) {
	html_registro_usuario = res;
});
