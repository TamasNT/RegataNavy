// Actualizar la interfaz de usuario de inicio de sesión
function updateLoginUI(email) {
	if (email_login == email && email_login !== "") {
		$("#menu-registrarme").hide();
		$(".profile-dropdown").show();
		$(".cart-icon").show();
	} else {
		$("#menu-registrarme").show();
		$(".profile-dropdown").hide();
		$(".cart-icon").hide();
	}
}

// Función para manejar el inicio de sesión exitoso
function loginSuccess(email) {
	updateLoginUI(email);
	$("#login-modal").css("display", "none");
	$("#login-modal").remove();
}

// Función para cerrar sesión
function logout() {
	$.post("cerrar-session-usuario", { email: email_login })  
		.done(function(response) {
			email_login = ""; 
			updateLoginUI();  
			Toast.fire({
				icon: "success",
				title: "Has cerrado sesión exitosamente"
			});   
		})
		.fail(function() {
			Toast.fire({
				icon: "error",
				title: "Error al cerrar sesión. Intente nuevamente"
			});
		});
}


// Función para enviar información de inicio de sesión
function enviarInfoUsuarioLogin() {
	let email = $("#emailInicio").val().trim();
	let password = $("#passInicio").val().trim();

	if (!email || !password) {
		Toast.fire({
			icon: "error",
			title: "Por favor, completa todos los campos"
		});
		return;
	}

	// Enviar los datos al servidor
	$.post("identificar-usuario",
		{
			email: email,
			pass: password
		}
	).done(function(response) {
		Toast.fire({
			icon: "success",
			title: response
		});
		email_login = email
		loginSuccess(email);
		if ($("#rememberMe").prop("checked")) {
			Cookies.set("email", $("#emailInicio").val(), { expires: 100 })
			Cookies.set("pass", $("#passInicio").val(), { expires: 100 })
		} else {

			if (typeof (Cookies.get("email")) != "undefined") {
				Cookies.remove("email")
			}
			if (typeof (Cookies.get("pass")) != "undefined") {
				Cookies.remove("pass")
			}
		}
	}).fail(function() {
		Toast.fire({
			icon: "error",
			title: "Error al iniciar sesión. Revise los datos e intente nuevamente"
		});
	});
}

// Función para enviar información de registro
function enviarInfoUsuarioAlServidor() {
    let nombre = $("#nombre").val().trim();
    let usuario = $("#usuario").val().trim();
    let email = $("#email").val().trim();
    let telefono = window.iti.getNumber();  // Si usas una librería como intl-tel-input
    let direccion = $("#direccion").val().trim();
    let pass = $("#pass").val().trim();

    // Limpiar mensajes de error previos
    $(".error-message").text("");

    // Validación de campos
    let isValid = true;

    // Validación de Nombre
    let regExpNombre = /^[a-zA-Z áéíóúñ]{4,40}$/;
    if (!regExpNombre.test(nombre)) {
        $("#error-nombre").text("El nombre debe tener entre 4 y 40 caracteres y solo puede contener letras y espacios.");
        isValid = false;
    }

    // Validación de Usuario
    let regExpUsuario = /^[a-zA-Z0-9_]{4,40}$/;
    if (!regExpUsuario.test(usuario)) {
        $("#error-usuario").text("El nombre de usuario debe tener entre 4 y 40 caracteres y solo puede contener letras, números y guiones bajos.");
        isValid = false;
    }

    // Validación de Email
    let regExpEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!regExpEmail.test(email)) {
        $("#error-email").text("Por favor, ingrese un correo electrónico válido.");
        isValid = false;
    }

    // Validación de Teléfono
    let regExpTelefono = /^[+]?[0-9]{5,40}$/;
    if (!regExpTelefono.test(telefono)) {
        $("#error-telefono").text("El número de teléfono debe ser válido.");
        isValid = false;
    }

    // Validación de Dirección
    let regExpDireccion = /^[a-zA-Z0-9áéíóúñ\s]{10,}$/;
    if (!regExpDireccion.test(direccion)) {
        $("#error-direccion").text("La dirección debe tener al menos 10 caracteres y puede contener letras, números y espacios.");
        isValid = false;
    }

    // Validación de Contraseña
    let regExpPass = /^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-záéíóúñÑ0-9!@#$%^&*(),.?":{}|<>]{4,20}$/;
    if (!regExpPass.test(pass)) {
        $("#error-pass").text("La contraseña debe tener entre 4 y 20 caracteres, al menos una mayúscula y un carácter especial.");
        isValid = false;
    }

    if (!isValid) {
        return; 
    }

    $.post("registrar-usuario-cliente", {
            nombre: nombre,
            usuario: usuario,
            email: email,
            telefono: telefono,
            direccion: direccion,
            pass: pass
        })
        .done(function(response) {
            // Limpiar mensajes de error al ser exitoso
            $(".error-message").text("");
            $("#login-modal").css("display", "none");
            $("#login-modal").remove();
			Toast.fire({
						icon: "success",
						title: response
					});
        })
        .fail(function(xhr) {
            // Limpiar mensajes de error previos
            $(".error-message").text("");
            if (xhr.status === 409) {  // Si el email ya está registrado
                $("#error-email").text("El email ya está registrado. Por favor, use otro.");
            } else {
                $("#error-general").text("Error al registrar el usuario. Intente nuevamente.");
            }
        });
}

