

function cargarListadoYates() {
	$.ajax("obtener-productos-json").done(function(respuesta) {
		allYachts = JSON.parse(respuesta);
		$(".hero").show();
		$.get("plantillas/listado_yates.html").done(function(template) {
			let texto_html = Mustache.render(template, { yates: allYachts });
			$("#contenedor").html(texto_html);

			const yachtCards = $(".yacht-card");
			const showAllButton = $("#show-all-button");
			const showAllContainer = $(".show-all-container");

			showAllButton.text("Ver todos");
			showAllContainer.show();

			yachtCards.slice(6).hide();  // Esconde los yates extra

			// Muestra el botón solo si hay más de 6 yates
			if (yachtCards.length > 6) {
				showAllButton.show();
			} else {
				showAllButton.hide();
			}

			// Se asegura de que el evento click se configure correctamente en cada carga
			showAllButton.off("click").on("click", function() {
				if (showAllButton.text() === "Ver todos") {
					yachtCards.slice(6).fadeIn(800, function() {
						showAllButton.text("Ver menos");
					});
				} else {
					$('html, body').animate({
						scrollTop: $("#contenedor").offset().top
					}, 800, function() {
						yachtCards.slice(6).fadeOut(200, function() {
							showAllButton.text("Ver todos");
						});
					});
				}
			});

			$(".cart-button").off("click").on("click", function() {
				mostrarDetallesYate($(this).attr("id-yate"));
			});
			$(".cart-icon").on("click", mostrarCarrito);


			$(".search-container").show();
			setupSearch();
		}).fail(function() {
			$("#contenedor").html("<p>Error al cargar la plantilla de los yates.</p>");
		});
	}).fail(function() {
		$("#contenedor").html("<p>Error al cargar la lista de los yates. Por favor, recarga la página.</p>");
	});
}


function verTodos() {
	cargarListadoYates();
	setTimeout(function() {
		$('html, body').animate({
			scrollTop: $("#contenedor").offset().top
		}, 800, function() {
			const yachtCards = $(".yacht-card");

			yachtCards.slice(6).fadeIn(800, function() { });
			$("#show-all-button").text("Ver menos");
		});
	}, 100);
}


function setupSearch() {
	const searchInput = $("#yacht-search");
	const searchResults = $("#search-results");
	let showingAllResults = false;

	searchInput.on("input", function() {
		const searchTerm = $(this).val().toLowerCase();
		if (searchTerm.length < 1) {
			searchResults.hide();
			return;
		}

		const filteredYachts = allYachts.filter(yacht =>
			yacht.nombre.toLowerCase().includes(searchTerm)
		);

		if (filteredYachts.length > 0) {
			displaySearchResults(filteredYachts);
		} else {
			searchResults.html('<div class="search-result-item">No se encontraron resultados</div>').show();
		}
	});

	function displaySearchResults(yachts) {
		const yachtCards = $(".yacht-card");
		const maxInitialResults = 5;
		const initialYachts = yachts.slice(0, maxInitialResults);
		let resultsHtml = initialYachts.map(createYachtResultHtml).join('');


		resultsHtml += `
                <div class="search-result-item" id="ver-todos-search" style="text-align:center; justify-content: center; align-items: center;">
                    <span>Ver todos (${allYachts.length})</span>
                </div>
            `;


		searchResults.html(resultsHtml).show();

		$("#ver-todos-search").on("click", function() {
			$("#yacht-search").val('');

			$("#ver-todos-search").on("mouseout", function() {
				$("#search-results").hide();
			})

			verTodos();

		});

	}

	function createYachtResultHtml(yacht) {
		return `
            <div class="search-result-item" data-id="${yacht.id}">
                <img src="/mostrar_imagen?id=${yacht.id}" alt="${yacht.nombre}" class="search-result-image">
                <span class="search-result-name">${yacht.nombre}</span>
            </div>
        `;
	}

	searchResults.on("click", ".search-result-item", function() {
		const yachtId = $(this).data("id");
		if (yachtId) {
			mostrarDetallesYate(yachtId);
			searchInput.val('');
			searchResults.hide();
		}
	});

	$(document).on("click", function(event) {
		if (!$(event.target).closest(".search-container").length) {
			searchResults.hide();
		}
	});
}

function mostrarDetallesYate(idYate) {
	$(".show-all-container").hide();

	console.log("Mostrar detalles del yate de id: " + idYate);

	$.getJSON("obtener-detalles-yate", { id: idYate })
		.done(function(res) {
			console.log("Recibido del servicio REST:", res);
			$(".hero").hide();
			$.get("plantillas/detalles_yate.html")
				.done(function(template) {
					let html = Mustache.render(template, res);
					$("#contenedor").html(html);
					$(".menu-item").on("click", cargarListadoYates);
					$(".volver-button").on("click", cargarListadoYates);
					$(".cart-icon").on("click", mostrarCarrito);
					$('.detail-yacht-buy-button').click(agregarYateAlCarrito);

				}).fail(function() {
					$("#contenedor").html("<p>Error al cargar la plantilla de detalles del yate.</p>");
				});
		})
		.fail(function() {
			Toast.fire({
				icon: "error",
				title: "Error al obtener los detalles del yate. Intenta nuevamente"
			});
		});
}

function agregarYateAlCarrito() {
	if (email_login == "") {
		Toast.fire({
			icon: "error",
			title: "Debes iniciar sesión para añadir al carrito"
		});
		return;
	}

	let idYate = $(this).attr("id-yate");

	$.post("agregar-productos-carrito", {
		id: idYate,
		cantidad: 1
	}).done(function(res) {
		if (res == "ok") {
			Toast.fire({
				icon: "success",
				title: "Yate añadido al carrito correctamente"
			});
		}
	})
}

function mostrarCarrito() {
	console.log("Mostrar carrito");
	$(".show-all-container").hide();
	$(".search-container").hide();
	$.getJSON("obtener-productos-carrito")
		.done(function(res) {
			console.log("Recibido del servicio REST:", res);
			$(".hero").hide();

			$.get("plantillas" + sufijo_idioma + "/carrito.html")
				.done(function(template) {
					let html = Mustache.render(template, res);
					$("#contenedor").html(html);
					$("#show-all-container").hide();

					$(".menu-item").on("click", cargarListadoYates);
					$("#realizar-pedido").on("click", checkout_paso_0);

					function calcularTotales() {
						let subtotal = 0;
						const ivaRate = 0.21;

						document.querySelectorAll('.cart-item').forEach(function(item) {
							const precio = parseFloat(item.querySelector('.item-price').textContent.replace('$', ''));
							const cantidad = parseInt(item.querySelector('.quantity-input').value);
							subtotal += precio * cantidad;
						});

						const iva = subtotal * ivaRate;
						const total = subtotal + iva;

						document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
						document.getElementById('iva').textContent = `$${iva.toFixed(2)}`;
						document.getElementById('total').textContent = `$${total.toFixed(2)}`;
					}

					document.querySelectorAll('.cart-item').forEach(function(item) {
						const minusButton = item.querySelector('.quantity-btn.minus');
						const plusButton = item.querySelector('.quantity-btn.plus');
						const quantityInput = item.querySelector('.quantity-input');
						const removeButton = item.querySelector('.remove-item');
						const idYate = item.querySelector('.item-image').src.split('id=')[1];

						minusButton.addEventListener('click', function() {
							let cantidad = parseInt(quantityInput.value);
							if (cantidad > 1) {
								cantidad--;
								actualizarCantidadProducto(idYate, cantidad);
								quantityInput.value = cantidad;
								calcularTotales();
							}
						});

						plusButton.addEventListener('click', function() {
							let cantidad = parseInt(quantityInput.value);
							if (cantidad < 10) {
								cantidad++;
								actualizarCantidadProducto(idYate, cantidad);
								quantityInput.value = cantidad;
								calcularTotales();
							}
						});

						quantityInput.addEventListener('change', function() {
							let cantidad = parseInt(quantityInput.value);
							if (cantidad < 1) cantidad = 1;
							if (cantidad > 10) cantidad = 10;
							actualizarCantidadProducto(idYate, cantidad);
							quantityInput.value = cantidad;
							calcularTotales();
						});

						removeButton.addEventListener('click', function() {
							eliminarProductoDelCarrito(idYate);
						});
					});

					calcularTotales();

				}).fail(function() {
					$("#contenedor").html("<p>Error al cargar la plantilla del carrito.</p>");
				});
		})
		.fail(function() {
			Toast.fire({
				icon: "error",
				title: "Error al obtener los detalles del carrito. Intenta nuevamente"
			});
		});
}

function actualizarCantidadProducto(id, cantidad) {
	$.post("actualizar-cantidad-producto-carrito", {
		id: id,
		cantidad: cantidad
	}).done(function(res) {
		if (res == "ok") {
			calcularTotales();
			Toast.fire({
				icon: "success",
				title: "Cantidad actualizada correctamente"
			});
		}
	}).fail(function() {
		Toast.fire({
			icon: "error",
			title: "Error al actualizar la cantidad. Intenta nuevamente"
		});
	});
}

function eliminarProductoDelCarrito(id) {
	$.post("eliminar-producto-carrito", {
		id: id
	}).done(function(res) {
		if (res == "ok") {
			Toast.fire({
				icon: "success",
				title: "Producto eliminado del carrito"
			});
			$(`img[src*="id=${id}"]`).closest('.cart-item').remove();
			calcularTotales();
		}
	}).fail(function() {
		Toast.fire({
			icon: "error",
			title: "Error al eliminar el producto. Intenta nuevamente"
		});
	});
}

$(document).ready(function() {
	cargarListadoYates();
});