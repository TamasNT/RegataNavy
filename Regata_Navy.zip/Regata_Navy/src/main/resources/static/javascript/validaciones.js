// Validaciones Javascript
function validarNombre(nombre) {
    const regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,50}$/;
    if (regex.test(nombre)) {
        document.getElementById('nombre-error').textContent = '';
        return true;
    } else {
        document.getElementById('nombre-error').textContent = 'El nombre debe contener solo letras y espacios, y tener entre 2 y 50 caracteres.';
        return false;
    }
}

function validarEmail(email) {
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (regex.test(email)) {
        document.getElementById('email-error').textContent = '';
        return true;
    } else {
        document.getElementById('email-error').textContent = 'Por favor, ingresa un email válido.';
        return false;
    }
}

function validarPass(pass) {
    if (pass.length >= 8) {
        document.getElementById('pass-error').textContent = '';
        return true;
    } else {
        document.getElementById('pass-error').textContent = 'La contraseña debe tener al menos 8 caracteres.';
        return false;
    }
}

function validarTelefono(telefono) {
    if (telefono.length > 5) {
        document.getElementById('telefono-error').textContent = '';
        return true;
    } else {
        document.getElementById('telefono-error').textContent = 'El teléfono debe tener más de 5 caracteres.';
        return false;
    }
}

function validarDireccion(direccion) {
    const trimmedDireccion = direccion.trim();
    if (trimmedDireccion.length >= 3) {
        document.getElementById('direccion-error').textContent = '';
        return true;
    } else {
        document.getElementById('direccion-error').textContent = 'La dirección debe tener al menos 3 caracteres y no puede estar vacía.';
        return false;
    }
}