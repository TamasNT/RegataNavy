$(document).ready(function() {
    // Cargar el encabezado y el pie de página
    $("#header-placeholder").load("plantillas" + sufijo_idioma + "/header.html", function() {
        const cartCount = document.querySelector('.cart-count');
        cartCount.textContent = '5'; 
        
        // Actualizar la interfaz de usuario de inicio de sesión
        updateLoginUI();
        
        // Agregar evento de escucha para cerrar sesión
        $("#cerrar-sesion").on("click", function(event) {
            event.preventDefault();
            logout();
        });
		
		$("#logo").on("click", function(event) {
				    cargarListadoYates();
				});
		
		
    });
    $("#footer-placeholder").load("plantillas" + sufijo_idioma + "/footer.html");
    
    // Desplazamiento suave para el botón CTA
    $(".cta-button").on("click", function(event) {
        event.preventDefault();
        const target = $(this).attr("href");
        $('html, body').animate({
            scrollTop: $(target).offset().top
        }, 800);
    });
	
    // Cargar el modal de inicio de sesión/registro
    $("#header-placeholder").on("click", "#menu-registrarme", loadLoginModal);
});