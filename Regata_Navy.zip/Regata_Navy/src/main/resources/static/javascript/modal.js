// Función para cargar el modal de inicio de sesión/registro
function loadLoginModal(event) {
    event.preventDefault();

    if (html_registro_usuario) {
        $("body").append(html_registro_usuario); 
        $("#login-modal").css("display", "block");

        // Rellenar los campos de email y contraseña si existen cookies
        if (typeof Cookies.get("email") !== "undefined") {
            $("#emailInicio").val(Cookies.get("email"));
        }
        if (typeof Cookies.get("pass") !== "undefined") {
            $("#passInicio").val(Cookies.get("pass"));
        }

        // Inicializar el input de teléfono
        var input = document.querySelector("#telefono");
        window.iti = window.intlTelInput(input, {
            initialCountry: "es",
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
        });

        // Cerrar el modal
        $(".close-button").click(function() {
            $("#login-modal").css("display", "none");
            $("#login-modal").remove();
        });

        // Cerrar el modal al hacer clic fuera de él
        $(window).click(function(event) {
            if (event.target.id === "login-modal") {
                $("#login-modal").css("display", "none");
                $("#login-modal").remove();
            }
        });

        // Cambiar entre formularios de inicio de sesión y registro
        $("#show-register").click(function() {
            $("#login-form").hide();
            $("#register-form").show();
            $("#form-title").text("Registrarse");
            $("#show-register").hide();
            $("#show-login").show();
        });

        $("#show-login").click(function() {
            $("#register-form").hide();
            $("#login-form").show();
            $("#form-title").text("Iniciar Sesión");
            $("#show-login").hide();
            $("#show-register").show();
        });

        // Agregar eventos de clic para los botones de inicio de sesión y registro
        $("#boton_inicio_usuario").click(enviarInfoUsuarioLogin);
        $("#boton_registro_usuario").click(enviarInfoUsuarioAlServidor);
    } else {
        console.error("Error: html_registro_usuario no está definido.");
    }
}
