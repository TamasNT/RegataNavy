package com.ares.tiendaEjemplo.serviciosJPAimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ares.tiendaEjemplo.model.Categoria;
import com.ares.tiendaEjemplo.servicios.ServicioCategorias;

@Service
@Transactional
public class ServicioCategoriaJPAimpl implements ServicioCategorias{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Categoria> obtenerCategorias() {
		return entityManager.createQuery("Select c from Categoria c").getResultList();
	}

}
