package com.ares.tiendaEjemplo.servicios;

import java.util.List;

import com.ares.tiendaEjemplo.model.Usuario;

public interface ServicioUsuarios {

	void registrarUsuario(Usuario u);
	
	List<Usuario> obtenerUsuarios();
	
	void borrarUsuario(int id);
	
	Usuario obtenerUsuarioPorId(int id);
	
	void actualizarUsuario(Usuario u);
	
	Usuario obtenerUsuarioPorEmailyPass(String email, String pass);

	boolean comprobarEmailExiste(String email);
	
}
