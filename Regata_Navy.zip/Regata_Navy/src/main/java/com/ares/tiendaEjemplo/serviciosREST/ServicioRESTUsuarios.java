package com.ares.tiendaEjemplo.serviciosREST;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ares.tiendaEjemplo.constantesValidaciones.ConstantesValidaciones;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.servicios.ServicioUsuarios;

@Controller
public class ServicioRESTUsuarios {

	@Autowired
	private ServicioUsuarios servicioUsuarios;

	@RequestMapping("registrar-usuario-cliente")
	public ResponseEntity<String> registrarUsuario(String nombre, String usuario, String email, String telefono,
			String direccion, String pass) {
		
		if( servicioUsuarios.comprobarEmailExiste(email) ) {
		    return new ResponseEntity<String>("El email ya está registrado", HttpStatus.CONFLICT);
		}

		Usuario u = new Usuario(nombre, usuario, email, telefono, direccion, pass);
		servicioUsuarios.registrarUsuario(u);
		return new ResponseEntity<String>("Usuario registrado correctamente", HttpStatus.OK);
	}

	@RequestMapping("identificar-usuario")
	public ResponseEntity<String> identificarUsuario(String email, String pass, HttpServletRequest request) {

		String respuesta = "";

		Usuario u = servicioUsuarios.obtenerUsuarioPorEmailyPass(email, pass);

		if (u != null) {
			respuesta = "Bienvenido " + u.getUsuario() + ". ¿Cuál es tu yate preferido? ";
			request.getSession().setAttribute("usuario", u);
		} else {
			respuesta = "Email o contraseñas incorrectos.";
		}

		return new ResponseEntity<String>(respuesta, HttpStatus.OK);
	}

	@RequestMapping("cerrar-session-usuario")
	public ResponseEntity<String> cerrarSesionUsuario(String email, String pass, HttpServletRequest request) {

		String respuesta = "";

		request.getSession().invalidate();
		respuesta = "Has cerrado sesión exitosamente.";

		return new ResponseEntity<String>(respuesta, HttpStatus.OK);
	}

}
