package com.ares.tiendaEjemplo.servicios;

import java.util.List;

import com.ares.tiendaEjemplo.model.Categoria;

public interface ServicioCategorias {
	
	List <Categoria> obtenerCategorias();
	

}
