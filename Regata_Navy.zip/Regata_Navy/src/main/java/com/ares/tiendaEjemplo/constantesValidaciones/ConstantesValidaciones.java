package com.ares.tiendaEjemplo.constantesValidaciones;

public class ConstantesValidaciones {
	
	public final static String regExpNombreRegistroUsuario = "^[a-zA-Z áéíóúñ]{4,40}$";
	
	public final static String regExpEmailRegistroUsuario = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
	
	public final static String regExpPassRegistroUsuario = "^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?\":{}|<>])[A-Za-záéíóúñÑ0-9!@#$%^&*(),.?\":{}|<>]{4,20}$";
	
	public final static String regExpDireccionRegistroUsuario = "^[a-zA-Z0-9áéíóúñ\\s]{10,}$";
	
	public final static String regExpTelefonoRegistroUsuario = "^[+]?[0-9]{5,40}$";

	public static final String regExpUsuarioRegistroUsuario = "^[a-zA-Z0-9_]{4,40}$";
	
}