package com.ares.tiendaEjemplo.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name = "yates")
public class Yate {
	
	@Id
    @GeneratedValue
    private int id;
    
    @Column(length = 120)
    private String nombre;
    private double precio;
    private int pasajeros;
    private double tamanyo;
    
    @Column(length = 650)
    private String descripcion;
    
    @Lob
    @Column(name = "imagen_portada")
    private byte[] imagenPortada;
    
    @ManyToOne(optional = true)
    private Categoria categoria;
    
    @OneToMany(mappedBy = "yate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductoPedido> productosPedido = new ArrayList<>();
    
    @OneToMany(mappedBy = "yate", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductoCarrito> productosCarrito = new ArrayList<>();
    
    private Date fechaUltimaModificacion;
    
    @Transient
    private int idCategoria;
    
    @Transient
    private MultipartFile portada;
    
    
    public void addProductoPedido(ProductoPedido productoPedido) {
        productosPedido.add(productoPedido);
        productoPedido.setYate(this);
    }
    
    public void removeProductoPedido(ProductoPedido productoPedido) {
        productosPedido.remove(productoPedido);
        productoPedido.setYate(null);
    }
    
    public void addProductoCarrito(ProductoCarrito productoCarrito) {
        productosCarrito.add(productoCarrito);
        productoCarrito.setYate(this);
    }
    
    public void removeProductoCarrito(ProductoCarrito productoCarrito) {
        productosCarrito.remove(productoCarrito);
        productoCarrito.setYate(null);
    }
    
	public byte[] getImagenPortada() {
		return imagenPortada;
	}
	public void setImagenPortada(byte[] imagenPortada) {
		this.imagenPortada = imagenPortada;
	}
	public int getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public Date getFechaUltimaModificacion() {
		return fechaUltimaModificacion;
	}
	public void setFechaUltimaModificacion(Date fechaUltimaModificacion) {
		this.fechaUltimaModificacion = fechaUltimaModificacion;
	}
	public MultipartFile getPortada() {
		return portada;
	}
	public void setPortada(MultipartFile portada) {
		this.portada = portada;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getPasajeros() {
		return pasajeros;
	}
	public void setPasajeros(int pasajeros) {
		this.pasajeros = pasajeros;
	}
	public double getTamanyo() {
		return tamanyo;
	}
	public void setTamanyo(double tamanyo) {
		this.tamanyo = tamanyo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public Yate(Categoria categoria, String nombre, double precio, int pasajeros, double tamanyo, String descripcion,
			Date fechaUltimaModificacion) {
		super();
		this.categoria = categoria;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.fechaUltimaModificacion = fechaUltimaModificacion;
	}
	public Yate(Categoria categoria, String nombre, double precio, int pasajeros, double tamanyo, String descripcion,
			MultipartFile portada, Date fechaUltimaModificacion) {
		super();
		this.categoria = categoria;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.portada = portada;
		this.fechaUltimaModificacion = fechaUltimaModificacion;
	}
	public Yate(Categoria categoria, int id, String nombre, double precio, int pasajeros, double tamanyo,
			String descripcion, MultipartFile portada, Date fechaUltimaModificacion) {
		super();
		this.categoria = categoria;
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.portada = portada;
		this.fechaUltimaModificacion = fechaUltimaModificacion;
	}
	public Yate(byte[] imagenPortada, String nombre, double precio, int pasajeros, double tamanyo, String descripcion) {
		super();
		this.imagenPortada = imagenPortada;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
	}
	public Yate(byte[] imagenPortada, int idCategoria, Categoria categoria, int id, String nombre, double precio,
			int pasajeros, double tamanyo, String descripcion, MultipartFile portada, Date fechaUltimaModificacion) {
		super();
		this.imagenPortada = imagenPortada;
		this.idCategoria = idCategoria;
		this.categoria = categoria;
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.portada = portada;
		this.fechaUltimaModificacion = fechaUltimaModificacion;
	}
	public Yate(String nombre, double precio, int pasajeros, double tamanyo, String descripcion) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
	}
	public Yate(String nombre, double precio, int pasajeros, double tamanyo, String descripcion,
			MultipartFile portada) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.portada = portada;
	}
	public Yate(int id, String nombre, double precio, int pasajeros, double tamanyo, String descripcion,
			MultipartFile portada) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
		this.portada = portada;
	}
	public Yate(int id, String nombre, double precio, int pasajeros, double tamanyo, String descripcion) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
		this.pasajeros = pasajeros;
		this.tamanyo = tamanyo;
		this.descripcion = descripcion;
	}
	public Yate() {
		super();
	}
}
