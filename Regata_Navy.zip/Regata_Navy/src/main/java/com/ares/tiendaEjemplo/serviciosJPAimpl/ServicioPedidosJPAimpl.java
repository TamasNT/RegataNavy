package com.ares.tiendaEjemplo.serviciosJPAimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ares.tiendaEjemplo.constantesSQL.ConstantesSQL;
import com.ares.tiendaEjemplo.model.Carrito;
import com.ares.tiendaEjemplo.model.Pedido;
import com.ares.tiendaEjemplo.model.ProductoCarrito;
import com.ares.tiendaEjemplo.model.ProductoPedido;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.model.estadosPedido.EstadosPedido;
import com.ares.tiendaEjemplo.model.tiposExtra.ResumenPedido;
import com.ares.tiendaEjemplo.servicios.ServicioCarrito;
import com.ares.tiendaEjemplo.servicios.ServicioPedidos;

@Service
@Transactional
public class ServicioPedidosJPAimpl implements ServicioPedidos{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private ServicioCarrito servicioCarrito;

	private Pedido obtenerPedidoActual(int idUsuario) throws Exception {
		
		Usuario usuario = entityManager.find(Usuario.class, idUsuario);
		Object pedidoEnProceso = null;
		
		List<Pedido> resultadoConsulta = entityManager.createQuery("SELECT p FROM Pedido p WHERE p.estado = :estado AND p.usuario.id = :usuario_id ").setParameter("estado", EstadosPedido.INCOMPLETO.name()).setParameter("usuario_id", idUsuario).getResultList();
		
		if( resultadoConsulta.size() == 1 ) {
			pedidoEnProceso = resultadoConsulta.get(0);
		}else if(resultadoConsulta.size() > 1 ) {
			throw new Exception("Se ha colado mas de un pedido incompleto para el mismo usuario");
		}
		
		Pedido pedido = null;
		if( pedidoEnProceso != null) {
			pedido = (Pedido) pedidoEnProceso;
		}else {
			pedido = new Pedido();
			pedido.setEstado(EstadosPedido.INCOMPLETO.name());
			pedido.setUsuario(usuario);
		}
		return pedido;		
	}
	
	@Override
	public void procesarPaso1(String nombreCompleto, String direccion, String provincia, int idUsuario) {
		try {
			Pedido p = obtenerPedidoActual(idUsuario);
			p.setNombreCompleto(nombreCompleto);
			p.setDireccion(direccion);
			p.setProvincia(provincia);
			
			entityManager.merge(p);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Hubo un problema obteniendo el pedido actual");
		}
		
	}

	@Override
	public void procesarPaso2(String titular, String numero, String tipoTarjeta, int idUsuario) {
		try {
			Pedido p = obtenerPedidoActual(idUsuario);
			p.setTitularTarjeta(titular);
			p.setNumeroTarjeta(numero);
			p.setTipoTarjeta(tipoTarjeta);
			entityManager.merge(p);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public ResumenPedido obtenerResumenDelPedido(int idUsuario) {
		ResumenPedido resumen = new ResumenPedido();
		try {
			Pedido p = obtenerPedidoActual(idUsuario);
			
			resumen.setNombreCompleto(p.getNombreCompleto());
			resumen.setDireccion(p.getDireccion());
			resumen.setProvincia(p.getProvincia());
			
			resumen.setTipoTarjeta(p.getTipoTarjeta());
			resumen.setTitularTarjeta(p.getTitularTarjeta());
			resumen.setNumeroTarjeta(p.getNumeroTarjeta());
		
			resumen.setYates(servicioCarrito.obtenerProductosCarritoUsuario(idUsuario));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resumen;
	}

	@Override
	public void confirmarPedido(int idUsuario) {
		try {
			Pedido pedido = obtenerPedidoActual(idUsuario);
			Usuario usuario = entityManager.find(Usuario.class, idUsuario);
			Carrito carrito = usuario.getCarrito();
			
			if( carrito != null && carrito.getProductoCarrito().size() > 0) {
				for (ProductoCarrito pc: carrito.getProductoCarrito()) {
					ProductoPedido pp = new ProductoPedido();
					pp.setCantidad(pc.getCantidad());
					pp.setYate(pc.getYate());
					pedido.getProductosPedido().add(pp);
					pp.setPedido(pedido);
					entityManager.persist(pp);
				}
			}
			
			Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_BORRAR_PRODUCTOS_CARRITO);
			query.setParameter("carrito_id", carrito.getId());
			query.executeUpdate();
			
			pedido.setEstado(EstadosPedido.COMPLETO.name());
			entityManager.merge(pedido);			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Pedido> obtenerPedidos() {
		return entityManager.createQuery("SELECT p FROM Pedido p ORDER BY p.id DESC").getResultList();
	}

	@Override
	public Pedido obtenerPedidoPorId(int idPedido) {
		return entityManager.find(Pedido.class, idPedido);
	}

	@Override
	public void actualizarEstadoPedido(int id, String estado) {
		Pedido p = entityManager.find(Pedido.class, id);
		p.setEstado(estado);
		entityManager.merge(p);
	}
	
}
