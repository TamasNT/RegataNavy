package com.ares.tiendaEjemplo.servicios;

import java.util.List;

import com.ares.tiendaEjemplo.model.Pedido;
import com.ares.tiendaEjemplo.model.tiposExtra.ResumenPedido;

public interface ServicioPedidos {

	List<Pedido> obtenerPedidos();
	
	Pedido obtenerPedidoPorId(int idPedido);		
	
	void procesarPaso1(String nombreCompleto, String direccion, String provincia, int idUsuario);
	
	void procesarPaso2(String titular, String numero, String tipoTarjeta, int idUsuario);
	
	ResumenPedido obtenerResumenDelPedido(int idUsuario);
	
	void confirmarPedido(int idUsuario);
	
	void actualizarEstadoPedido(int id, String estado);

		
}
