package com.ares.tiendaEjemplo.constantesSQL;

public class ConstantesSQL {
	
	public final static String SQL_OBTENER_DETALLES_YATE = "Select y.nombre, y.precio, y.pasajeros, y.tamanyo, y.descripcion, c.nombre AS categoria, y.id from yates as y JOIN categoria c ON y.categoria_id = c.id where y.id = :id";

	public static final String SQL_OBTENER_LISTADO_YATES = "Select y.nombre, y.precio, y.pasajeros, y.tamanyo, y.descripcion, y.id from yates as y";
	
	public static final String SQL_OBTENER_YATES_CARRITO = "SELECT yates.id, yates.nombre, yates.precio, producto_carrito.cantidad FROM producto_carrito, yates WHERE yates.id = producto_carrito.yate_id AND producto_carrito.carrito_id = :carrito_id ORDER BY yates.precio desc;";
	
	public static final String SQL_BORRAR_PRODUCTOS_CARRITO ="DELETE FROM producto_carrito WHERE carrito_id = :carrito_id ";
	
	public static final String SQL_OBTENER_ID_USUARIO_POR_EMAIL = "SELECT id FROM usuario where email = :email";
	
}
