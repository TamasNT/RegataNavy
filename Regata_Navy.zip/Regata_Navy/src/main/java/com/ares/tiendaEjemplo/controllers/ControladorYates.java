package com.ares.tiendaEjemplo.controllers;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ares.tiendaEjemplo.constantesValidaciones.ConstantesValidaciones;
import com.ares.tiendaEjemplo.model.Yate;
import com.ares.tiendaEjemplo.servicios.ServicioCategorias;
import com.ares.tiendaEjemplo.servicios.ServicioYates;

@Controller
@RequestMapping("admin/")
public class ControladorYates {

	@Autowired
	private ServicioYates servicioYates;

	@Autowired
	private ServicioCategorias servicioCategorias;
	
	@RequestMapping("yates")
	public String obtenerYates(@RequestParam(name = "nombre", defaultValue = "") String nombre,  Model model) {
		List<Yate> yates = servicioYates.obtenerYates(nombre);
		model.addAttribute("yates", yates);
		model.addAttribute("nombre",nombre);
		return "admin/yates";
	}

	@RequestMapping("yates-borrar")
	public String borrarYate(String id, Model model) {
		servicioYates.borrarYate(Integer.parseInt(id));
		return obtenerYates("",model);
	}

	@RequestMapping("yates-nuevo")
	public String nuevoYate(Model model) {
		Yate y = new Yate();
		model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
		model.addAttribute("nuevoYate", y);
		return "admin/yates-nuevo";
	}

	@RequestMapping("yates-guardar-nuevo")
	public String guardarNuevoYate(@Valid @ModelAttribute("nuevoYate") Yate nuevoYate, 
	                               BindingResult bindingResult, Model model, 
	                               @RequestParam(value = "imagen_portada", required = false) MultipartFile imagenPortada) {
	    
	    // Validaciones personalizadas
	    if (!validarCampo(nuevoYate.getNombre(), "^[a-zA-Z áéíóúñ]{4,40}$")) {
	        model.addAttribute("errorNombre", "El nombre del yate debe tener entre 4-40 caracteres y no poseer caracteres especiales.");
	    }
	    if (!validarCampo(nuevoYate.getDescripcion(), "^[a-zA-Z0-9áéíóúñ\\s,\\.]{10,255}$")) {
	        model.addAttribute("errorDescripcion", "La descripción debe tener al menos 10 caracteres y no contener caracteres especiales.");
	    }
	    if (nuevoYate.getPrecio() <= 0) {
	        model.addAttribute("errorPrecio", "El precio debe ser mayor que cero.");
	    }
	    if (nuevoYate.getTamanyo() <= 0) {
	        model.addAttribute("errorTamanyo", "El tamaño debe ser mayor que cero.");
	    }

	    // Validar tamaño de la imagen (no mayor de 5MB)
	    if (imagenPortada != null && imagenPortada.getSize() > 5 * 1024 * 1024) {
	        model.addAttribute("errorImagen", "La imagen no puede pesar más de 5MB.");
	    }

	    // Si hay errores de validación, devolver a la página de nuevo yate con los errores
	    if (model.containsAttribute("errorNombre") || model.containsAttribute("errorDescripcion") ||
	        model.containsAttribute("errorPrecio") || model.containsAttribute("errorTamanyo") || 
	        model.containsAttribute("errorImagen")) {
	        
	        // Volver a cargar las categorías para que el formulario tenga las opciones correctas
	        model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
	        return "admin/yates-nuevo"; // Volver a la página de nuevo yate con los errores
	    }

	    // Procesar la imagen si está presente
	    if (imagenPortada != null && !imagenPortada.isEmpty()) {
	        try {
	            byte[] imagenBytes = imagenPortada.getBytes();
	            nuevoYate.setImagenPortada(imagenBytes);
	        } catch (IOException e) {
	            e.printStackTrace();
	            model.addAttribute("errorImagen", "Hubo un problema al subir la imagen.");
	            return "admin/yates-nuevo"; // Si hay error al procesar la imagen, volver al formulario
	        }
	    }

	    // Registrar el nuevo yate en la base de datos
	    servicioYates.registrarYate(nuevoYate);

	    // Redirigir a la página de listado de yates después de registrar el nuevo yate
	    return "redirect:/admin/yates"; // Redirigir al listado de yates
	}



	@RequestMapping("yates-editar")
	public String editarYate(String id, Model model) {
		Yate y = servicioYates.obtenerYatePorId(Integer.parseInt(id));
		model.addAttribute("yateEditar", y);
		model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
		return "admin/yates-editar";
	}

	@RequestMapping("yates-guardar-cambios")
	public String guardarCambiosYate(@ModelAttribute("yateEditar") Yate yateEditar, 
	                                  @RequestParam(value = "imagen_portada", required = false) MultipartFile imagenPortada, 
	                                  Model model) {

	    // Validaciones personalizadas
	    if (!validarCampo(yateEditar.getNombre(), "^[a-zA-Z áéíóúñ]{4,40}$")) {
	        model.addAttribute("errorNombre", "El nombre del yate debe tener entre 4-40 caracteres y no poseer caracteres especiales.");
	    }
	    if (!validarCampo(yateEditar.getDescripcion(), "^[a-zA-Z0-9áéíóúñ\\s,\\.]{10,255}$")) {
	        model.addAttribute("errorDescripcion", "La descripción debe tener al menos 10 caracteres y no contener caracteres especiales.");
	    }
	    if (yateEditar.getPrecio() <= 0) {
	        model.addAttribute("errorPrecio", "El precio debe ser mayor que cero.");
	    }
	    if (yateEditar.getTamanyo() <= 0) {
	        model.addAttribute("errorTamanyo", "El tamaño debe ser mayor que cero.");
	    }

	    // Validar tamaño de la imagen (no mayor de 5MB)
	    if (yateEditar.getPortada() != null && yateEditar.getPortada().getSize() > 5 * 1024 * 1024) {
	        model.addAttribute("errorImagen", "La imagen no puede pesar más de 5MB.");
	    }
	    
	    // Si hay errores de validación, no guardar y devolver a la página de edición
	    if (model.containsAttribute("errorNombre") || model.containsAttribute("errorDescripcion") ||
	        model.containsAttribute("errorPrecio") || model.containsAttribute("errorTamanyo") || 
	        model.containsAttribute("errorImagen")) {
	        
	        model.addAttribute("categorias", servicioCategorias.obtenerCategorias());
	        return "admin/yates-editar"; 
	    }

	    if (imagenPortada != null && !imagenPortada.isEmpty()) {
	        try {
	            byte[] imagenBytes = imagenPortada.getBytes();
	            yateEditar.setImagenPortada(imagenBytes);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    } else {
	        // Si no hay nueva imagen, se conserva la imagen existente
	        Yate yateExistente = servicioYates.obtenerYatePorId(yateEditar.getId());
	        yateEditar.setImagenPortada(yateExistente.getImagenPortada());
	    }

	    servicioYates.actualizarYate(yateEditar);

	    return "redirect:/admin/yates";
	}

	
	 private boolean validarCampo(String campo, String regex) {
	        return Pattern.matches(regex, campo);
	  }


}
