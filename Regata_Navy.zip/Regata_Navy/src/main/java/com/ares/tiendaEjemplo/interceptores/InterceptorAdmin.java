package com.ares.tiendaEjemplo.interceptores;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class InterceptorAdmin implements HandlerInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		String passAdmin = "123";

		if (request.getParameter("pass-login-admin") != null) {
			if (request.getParameter("pass-login-admin").equals(passAdmin)) {
				request.getSession().setAttribute("token-admin", "ok");
			}
		}

		if (request.getRequestURI().contains("/admin/")) {
			if (!(request.getSession().getAttribute("token-admin") != null
					&& request.getSession().getAttribute("token-admin").equals("ok"))) {
				response.sendRedirect("../loginAdmin");
				return false;
			}
		}

		return true;
	}

}
