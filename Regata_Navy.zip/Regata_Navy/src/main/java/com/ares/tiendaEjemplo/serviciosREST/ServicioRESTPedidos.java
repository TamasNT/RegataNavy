package com.ares.tiendaEjemplo.serviciosREST;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.model.tiposExtra.ResumenPedido;
import com.ares.tiendaEjemplo.servicios.ServicioPedidos;

@RestController
public class ServicioRESTPedidos {
	
	@Autowired
	private ServicioPedidos servicioPedidos;
	
	@RequestMapping("realizar-pedido-paso1")
	public String realizarPedidoPaso1(String nombre, String direccion, String provincia, HttpServletRequest request) {
		
		Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		
		servicioPedidos.procesarPaso1(nombre, direccion, provincia, u.getId());	
		
		return "ok";
	}
	
	@RequestMapping("realizar-pedido-paso2")
	public ResumenPedido realizarPedidoPaso2(String tarjeta, String numero, String titular, HttpServletRequest request) {
		
		Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		
		servicioPedidos.procesarPaso2(titular, numero, tarjeta, u.getId());
		
		ResumenPedido resumen = servicioPedidos.obtenerResumenDelPedido(u.getId());
		
		return resumen;
	}
	
	@RequestMapping("confirmar-pedido")
	public String confirmarPedido(HttpServletRequest request) {
		
		Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		
		servicioPedidos.confirmarPedido(u.getId());
		
		return "pedido completado";
	}

}
