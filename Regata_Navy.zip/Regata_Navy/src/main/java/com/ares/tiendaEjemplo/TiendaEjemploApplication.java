package com.ares.tiendaEjemplo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaEjemploApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaEjemploApplication.class, args);
	}

}
