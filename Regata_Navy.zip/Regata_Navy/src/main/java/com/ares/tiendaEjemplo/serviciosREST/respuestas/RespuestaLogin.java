package com.ares.tiendaEjemplo.serviciosREST.respuestas;

public class RespuestaLogin {
	
	private String operacion;
	
	private String email;
	
	
	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public RespuestaLogin() {
		super();
	}
	
	public RespuestaLogin(String operacion, String email) {
		super();
		this.operacion = operacion;
		this.email = email;
	}
}
