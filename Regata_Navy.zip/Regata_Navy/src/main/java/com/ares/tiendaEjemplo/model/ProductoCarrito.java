package com.ares.tiendaEjemplo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class ProductoCarrito {

	@Id
	@GeneratedValue
	private int id;

	@ManyToOne
	@JoinColumn(name = "carrito_id")
	private Carrito carrito;

	@ManyToOne
	@JoinColumn(name = "yate_id")
	private Yate yate;

	private int cantidad;

	public Yate getYate() {
		return yate;
	}

	public void setYate(Yate yate) {
		this.yate = yate;
	}

	public Carrito getCarrito() {
		return carrito;
	}

	public void setCarrito(Carrito carrito) {
		this.carrito = carrito;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ProductoCarrito() {
		super();
	}

	public ProductoCarrito(Yate yate, Carrito carrito, int cantidad, int id) {
		super();
		this.yate = yate;
		this.carrito = carrito;
		this.cantidad = cantidad;
		this.id = id;
	}

	public ProductoCarrito(Yate yate, Carrito carrito, int cantidad) {
		super();
		this.yate = yate;
		this.carrito = carrito;
		this.cantidad = cantidad;
	}

}
