package com.ares.tiendaEjemplo.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Carrito {

	@OneToOne(mappedBy = "carrito")
    private Usuario usuario;

    @OneToMany(mappedBy = "carrito", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductoCarrito> productoCarrito = new ArrayList<ProductoCarrito>();
	
	private Date ultimoUso;
	
	@Id
	@GeneratedValue
	private int id;
	


	public List<ProductoCarrito> getProductoCarrito() {
		return productoCarrito;
	}

	public void setProductoCarrito(List<ProductoCarrito> productoCarrito) {
		this.productoCarrito = productoCarrito;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Date getUltimoUso() {
		return ultimoUso;
	}

	public void setUltimoUso(Date ultimoUso) {
		this.ultimoUso = ultimoUso;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

		
}
