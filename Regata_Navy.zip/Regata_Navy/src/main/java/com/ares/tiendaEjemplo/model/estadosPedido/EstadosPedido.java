package com.ares.tiendaEjemplo.model.estadosPedido;

public enum EstadosPedido {

	INCOMPLETO,
	COMPLETO,
	FINALIZADO
	
}
