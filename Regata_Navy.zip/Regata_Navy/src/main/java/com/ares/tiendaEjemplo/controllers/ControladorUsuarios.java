package com.ares.tiendaEjemplo.controllers;

import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ares.tiendaEjemplo.constantesValidaciones.ConstantesValidaciones;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.servicios.ServicioUsuarios;

@Controller
@RequestMapping("admin/")
public class ControladorUsuarios {
    
    @Autowired
    private ServicioUsuarios servicioUsuarios;
    
    @RequestMapping("usuarios")
    public String obtenerUsuarios(Model model) {
        List<Usuario> usuarios = servicioUsuarios.obtenerUsuarios();
        model.addAttribute("usuarios", usuarios);
        return "admin/usuarios";
    }
    
    @RequestMapping("usuarios-borrar")
    public String borrarUsuario(String id, Model model) {
        servicioUsuarios.borrarUsuario(Integer.parseInt(id));
        return obtenerUsuarios(model);
    }
    
    @RequestMapping("usuario-nuevo")
    public String nuevoUsuario(Model model) {
        Usuario nuevoUsuario = new Usuario();
        model.addAttribute("nuevoUsuario", nuevoUsuario);
        return "admin/usuarios-nuevo";
    }
    
    @RequestMapping("usuarios-guardar-nuevo")
    public String guardarNuevoUsuario(@Valid @ModelAttribute("nuevoUsuario") Usuario nuevoUsuario, BindingResult bindingResult, Model model) {
    	
    	if( servicioUsuarios.comprobarEmailExiste(nuevoUsuario.getEmail()) ) {
    		model.addAttribute("errorEmail", "Ya existe un usuario con este correo");
    		return "admin/usuarios-nuevo";
		}
    	
        if (bindingResult.hasErrors()) {
            return "admin/usuarios-nuevo";
        }

        // Validaciones personalizadas
        if (!validarCampo(nuevoUsuario.getNombre(), ConstantesValidaciones.regExpNombreRegistroUsuario)) {
            model.addAttribute("errorNombre", "El nombre de usuario debe tener al menos 4 caracteres y no poseer caracteres especiales (.;%$@?).");
            return "admin/usuarios-nuevo";
        }
        if (!validarCampo(nuevoUsuario.getUsuario(), ConstantesValidaciones.regExpUsuarioRegistroUsuario)) {
            model.addAttribute("errorUsuario", "El nombre de usuario debe tener al menos 4 caracteres y no poseer caracteres especiales (.;%$@?).");
            return "admin/usuarios-nuevo";
        }
        if (!validarCampo(nuevoUsuario.getEmail(), ConstantesValidaciones.regExpEmailRegistroUsuario)) {
            model.addAttribute("errorEmail", "Debes introducir un email válido.");
            return "admin/usuarios-nuevo";
        }
        if (!validarCampo(nuevoUsuario.getTelefono(), ConstantesValidaciones.regExpTelefonoRegistroUsuario)) {
            model.addAttribute("errorTelefono", "El teléfono no puede tener espacios y debe tener mínimo 5 números.");
            return "admin/usuarios-nuevo";
        }
        if (!validarCampo(nuevoUsuario.getDireccion(), ConstantesValidaciones.regExpDireccionRegistroUsuario)) {
            model.addAttribute("errorDireccion", "La dirección debe tener al menos 10 caracteres y no contener caracteres especiales (.;%$@?)");
            return "admin/usuarios-nuevo";
        }
        if (!validarCampo(nuevoUsuario.getPass(), ConstantesValidaciones.regExpPassRegistroUsuario)) {
            model.addAttribute("errorPass", "La contraseña debe tener entre 4-20 caracteres, una máyuscula al menos y algun caracter especial");
            return "admin/usuarios-nuevo";
        }

        servicioUsuarios.registrarUsuario(nuevoUsuario);
        return "redirect:/admin/usuarios";
    }

    private boolean validarCampo(String campo, String regex) {
        return Pattern.matches(regex, campo);
    }
    
    @RequestMapping("usuario-editar")
    public String editarUsuario(String id, Model model) {
        Usuario usuario = servicioUsuarios.obtenerUsuarioPorId(Integer.parseInt(id));
        model.addAttribute("usuarioEditar", usuario);
        return "admin/usuarios-editar";
    }
    
    @RequestMapping("usuarios-guardar-cambios")
    public String guardarCambiosUsuario(@Valid @ModelAttribute("usuarioEditar") Usuario usuarioEditar, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "admin/usuarios-editar";
        }
        // Validaciones personalizadas
        if (!validarCampo(usuarioEditar.getNombre(), ConstantesValidaciones.regExpNombreRegistroUsuario)) {
            model.addAttribute("errorNombre", "El nombre de usuario debe tener entre 2-10 caracteres y no poseer caracteres especiales (.;%$@?).");
            return "admin/usuarios-editar";
        }
        if (!validarCampo(usuarioEditar.getUsuario(), ConstantesValidaciones.regExpUsuarioRegistroUsuario)) {
            model.addAttribute("errorUsuario", "El nombre de usuario debe tener entre 2-10 caracteres y no poseer caracteres especiales (.;%$@?).");
            return "admin/usuarios-editar";
        }
        if (!validarCampo(usuarioEditar.getEmail(), ConstantesValidaciones.regExpEmailRegistroUsuario)) {
            model.addAttribute("errorEmail", "Debes introducir un email válido.");
            return "admin/usuarios-editar";
        }
        if (!validarCampo(usuarioEditar.getTelefono(), ConstantesValidaciones.regExpTelefonoRegistroUsuario)) {
            model.addAttribute("errorTelefono", "El teléfono no puede tener espacios y debe tener mínimo 5 números.");
            return "admin/usuarios-editar";
        }
        if (!validarCampo(usuarioEditar.getDireccion(), ConstantesValidaciones.regExpDireccionRegistroUsuario)) {
            model.addAttribute("errorDireccion", "La dirección debe tener al menos 10 caracteres y no contener caracteres especiales (.;%$@?)");
            return "admin/usuarios-editar";
        }
        // No validamos la contraseña aquí ya que no se edita en este formulario

        servicioUsuarios.actualizarUsuario(usuarioEditar);
        return "redirect:/admin/usuarios";
    }
}
