package com.ares.tiendaEjemplo.servicioSetUp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ares.tiendaEjemplo.model.Categoria;
import com.ares.tiendaEjemplo.model.Pedido;
import com.ares.tiendaEjemplo.model.ProductoPedido;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.model.Yate;
import com.ares.tiendaEjemplo.model.estadosPedido.EstadosPedido;
import com.ares.tiendaEjemplo.servicios.ServicioCarrito;


@Service
@Transactional
public class SetUpJPAimpl implements SetUp{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private ServicioCarrito servicioCarrito;
	
	@Override
	public void setUp() {
		
		com.ares.tiendaEjemplo.model.SetUp registroSetUp = null;
		
		try {
			registroSetUp = (com.ares.tiendaEjemplo.model.SetUp) entityManager.createQuery("Select s from SetUp as s").getSingleResult();
		} catch (Exception e) {
			System.out.println("No se encontró ningún registro de SetUp, comenzamos setup...");
		}
		
		if (registroSetUp == null || ! registroSetUp.isCompleto()) {
			
			Path imagen1 = Paths.get("src/main/resources/static/imagenes/yates/1.jpg");
            Path imagen2 = Paths.get("src/main/resources/static/imagenes/yates/2.jpg");
            Path imagen3 = Paths.get("src/main/resources/static/imagenes/yates/3.jpg");
            Path imagen4 = Paths.get("src/main/resources/static/imagenes/yates/4.jpg");
            Path imagen5 = Paths.get("src/main/resources/static/imagenes/yates/5.jpg");
            Path imagen6 = Paths.get("src/main/resources/static/imagenes/yates/6.jpg");
            Path imagen7 = Paths.get("src/main/resources/static/imagenes/yates/7.jpg");
            Path imagen8 = Paths.get("src/main/resources/static/imagenes/yates/8.jpg");
            Path imagen9 = Paths.get("src/main/resources/static/imagenes/yates/9.jpg");
            Path imagen10 = Paths.get("src/main/resources/static/imagenes/yates/10.jpg");
            Path imagen11 = Paths.get("src/main/resources/static/imagenes/yates/11.jpg");
            Path imagen12 = Paths.get("src/main/resources/static/imagenes/yates/12.jpg");
            Path imagen13 = Paths.get("src/main/resources/static/imagenes/yates/13.jpg");
            Path imagen14 = Paths.get("src/main/resources/static/imagenes/yates/14.jpg");
            Path imagen15 = Paths.get("src/main/resources/static/imagenes/yates/15.jpg");
            Path imagen16 = Paths.get("src/main/resources/static/imagenes/yates/16.jpg");
            Path imagen17 = Paths.get("src/main/resources/static/imagenes/yates/17.jpg");
            Path imagen18 = Paths.get("src/main/resources/static/imagenes/yates/18.jpg");

			
			Categoria lujo = new Categoria("Lujo", "Yate de lujo");
			Categoria deportivo = new Categoria("Deportivo", "Yate deportivo");
			Categoria exploracion = new Categoria("Exploracion", "Yate de exploracion");
			Categoria familiar = new Categoria("Familiar", "Yate familiar");
			
			entityManager.persist(lujo);
			entityManager.persist(deportivo);
			entityManager.persist(exploracion);
			entityManager.persist(familiar);
			
			Yate y1 = new Yate("Yate Lujo Atlántico", 1200000.50, 10, 25.50, "Yate de lujo con acabados premium y capacidad para 10 pasajeros.");
			y1.setCategoria(lujo);
			try {
			    y1.setImagenPortada(Files.readAllBytes(imagen1));
			    entityManager.persist(y1);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y2 = new Yate("Yate Deportivo Veloz", 850000.75, 6, 18.75, "Yate deportivo de alta velocidad con diseño aerodinámico.");
			y2.setCategoria(deportivo);
			try {
			    y2.setImagenPortada(Files.readAllBytes(imagen2));
			    entityManager.persist(y2);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y3 = new Yate("Catamarán Explorer", 1500000.00, 12, 30.80, "Catamarán de doble casco ideal para exploraciones largas en el mar.");
			y3.setCategoria(exploracion);
			try {
			    y3.setImagenPortada(Files.readAllBytes(imagen3));
			    entityManager.persist(y3);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y4 = new Yate("Yate Familiar Serenity", 950000.00, 8, 22.50, "Yate familiar con todas las comodidades y espacio amplio para 8 pasajeros.");
			y4.setCategoria(familiar);
			try {
			    y4.setImagenPortada(Files.readAllBytes(imagen4));
			    entityManager.persist(y4);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y5 = new Yate("Mega Yate Oceánico", 5000000.95, 20, 45.75, "Mega yate de lujo con piscina, helipuerto y capacidad para 20 pasajeros.");
			y5.setCategoria(lujo);
			try {
			    y5.setImagenPortada(Files.readAllBytes(imagen5));
			    entityManager.persist(y5);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y6 = new Yate("Yate Lujo de Monaco", 2500000.00, 15, 35.50, "Yate de lujo de gran tamaño y capacidad para 15 pasajeros.");
			y6.setCategoria(lujo);
			try {
			    y6.setImagenPortada(Files.readAllBytes(imagen6));
			    entityManager.persist(y6);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y7 = new Yate("Yate Aventura Extrema", 1300000.25, 10, 26.80, "Yate diseñado para aventuras extremas y viajes largos en mar abierto.");
			y7.setCategoria(exploracion);
			try {
			    y7.setImagenPortada(Files.readAllBytes(imagen7));
			    entityManager.persist(y7);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y8 = new Yate("Yate Deportivo Thunder", 900000.00, 5, 20.00, "Yate deportivo con motor turbo para altas velocidades.");
			y8.setCategoria(deportivo);
			try {
			    y8.setImagenPortada(Files.readAllBytes(imagen8));
			    entityManager.persist(y8);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y9 = new Yate("Catamarán Caribbean Breeze", 1600000.80, 14, 32.00, "Catamarán ideal para cruceros largos y exploraciones en el Caribe.");
			y9.setCategoria(exploracion);
			try {
			    y9.setImagenPortada(Files.readAllBytes(imagen9));
			    entityManager.persist(y9);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y10 = new Yate("Yate Familiar Sunset", 975000.00, 7, 24.00, "Yate familiar con terraza y salón para relajarse al atardecer.");
			y10.setCategoria(familiar);
			try {
			    y10.setImagenPortada(Files.readAllBytes(imagen10));
			    entityManager.persist(y10);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y11 = new Yate("Mega Yate Atlantis", 5500000.95, 25, 50.00, "Mega yate de lujo con spa, gimnasio, y capacidad para 25 pasajeros.");
			y11.setCategoria(lujo);
			try {
			    y11.setImagenPortada(Files.readAllBytes(imagen11));
			    entityManager.persist(y11);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y12 = new Yate("Yate Prestige Elite", 2700000.00, 16, 36.50, "Yate de lujo con acabados personalizados y detalles de alta gama.");
			y12.setCategoria(lujo);
			try {
			    y12.setImagenPortada(Files.readAllBytes(imagen12));
			    entityManager.persist(y12);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y13 = new Yate("Yate Deportivo Flash", 780000.50, 4, 17.25, "Yate deportivo con cabina aerodinámica y alto rendimiento.");
			y13.setCategoria(deportivo);
			try {
			    y13.setImagenPortada(Files.readAllBytes(imagen13));
			    entityManager.persist(y13);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y14 = new Yate("Catamarán Ocean Explorer", 1450000.00, 11, 31.75, "Catamarán para viajes largos con estabilidad extra en aguas abiertas.");
			y14.setCategoria(exploracion);
			try {
			    y14.setImagenPortada(Files.readAllBytes(imagen14));
			    entityManager.persist(y14);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y15 = new Yate("Yate Familiar Aqua Bliss", 890000.00, 9, 23.50, "Yate familiar ideal para viajes en grupo con espacios amplios.");
			y15.setCategoria(familiar);
			try {
			    y15.setImagenPortada(Files.readAllBytes(imagen15));
			    entityManager.persist(y15);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y16 = new Yate("Yate Lujo Estrella", 2600000.00, 18, 40.25, "Yate de lujo con cubierta espaciosa y bar de entretenimiento.");
			y16.setCategoria(lujo);
			try {
			    y16.setImagenPortada(Files.readAllBytes(imagen16));
			    entityManager.persist(y16);
			} catch (IOException e) {
			    e.printStackTrace();
			}

			Yate y17 = new Yate("Yate Aventura Ártico", 1550000.00, 10, 27.90, "Yate para exploraciones en climas fríos, equipado para ambientes extremos.");
			y17.setCategoria(exploracion);
			try {
			    y17.setImagenPortada(Files.readAllBytes(imagen17));
			    entityManager.persist(y17);
			} catch (IOException e) {
			    e.printStackTrace();
			}
			
			Yate y18 = new Yate("Yate Deportivo del Caribe", 230000.00, 10, 27.90, "Yate para actividades deportivas en el caribe, equipado para actividades extremas.");
			y18.setCategoria(deportivo);
			try {
			    y18.setImagenPortada(Files.readAllBytes(imagen18));
			    entityManager.persist(y18);
			} catch (IOException e) {
			    e.printStackTrace();
			}



			entityManager.persist(y1);
			entityManager.persist(y2);
			entityManager.persist(y3);
			entityManager.persist(y4);
			entityManager.persist(y5);
			entityManager.persist(y6);
			
			Usuario u1 = new Usuario("Carlos Pedro", "carlos", "carlos@gmail.com", "987654321", "Calle Ejemplo 123", "carlos123");
			Usuario u2 = new Usuario("Ana de Armas", "ana", "ana@gmail.com", "123456789", "Avenida Principal 456", "ana456");
			Usuario u3 = new Usuario("Tamas Carlos Nagy", "Tomito", "tamasnagytrejo@gmail.com", "+34642758855", "Calle de Peña Nueva 26", "123");
			entityManager.persist(u1);
			entityManager.persist(u2);
			entityManager.persist(u3);
			
			servicioCarrito.agregarProducto(y1.getId(), u3.getId(), 2);
			servicioCarrito.agregarProducto(y3.getId(), u3.getId(), 1);
			servicioCarrito.agregarProducto(y6.getId(), u3.getId(), 3);
			
			Pedido pedido1 = new Pedido();
			pedido1.setNombreCompleto("Juan Martinez");
			pedido1.setDireccion("argüelles 12 28080 Madrid");
			pedido1.setProvincia("Madrid");
			pedido1.setTipoTarjeta("VISA");
			pedido1.setTitularTarjeta("Juan Martinez");
			pedido1.setNumeroTarjeta("3310 2201 5445 5555");
			
			pedido1.setUsuario(u1);
			pedido1.setEstado(EstadosPedido.COMPLETO.name());
			entityManager.persist(pedido1);
			ProductoPedido pp1 = new ProductoPedido();
			pp1.setPedido(pedido1);
			pp1.setYate(y1);
			pp1.setCantidad(2);
			entityManager.persist(pp1);

			Pedido pedido2 = new Pedido();
			pedido2.setNombreCompleto("N. Completo 2");
			pedido2.setDireccion("Info Direccion 2");
			pedido2.setProvincia("Info Provincia 2");
			pedido2.setTipoTarjeta("VISA");
			pedido2.setNumeroTarjeta("4444 5555 6666 7777");
			pedido2.setTitularTarjeta("Info titular Tarketa 2");
			pedido2.setUsuario(u3);
			pedido2.setEstado(EstadosPedido.FINALIZADO.name());
			entityManager.persist(pedido2);
			ProductoPedido pp2 = new ProductoPedido();
			pp2.setPedido(pedido2);
			pp2.setYate(y3);
			pp2.setCantidad(1);
			entityManager.persist(pp2);			
			
			
			Pedido pedido5 = new Pedido();
			pedido5.setNombreCompleto("N. Completo 5");
			pedido5.setDireccion("Info Direccion 5");
			pedido5.setProvincia("Info Provincia 5");
			pedido5.setTipoTarjeta("Discover");
			pedido5.setNumeroTarjeta("3333 4444 5555 6666");
			pedido5.setTitularTarjeta("Info titular Tarjeta 5");
			pedido5.setUsuario(u1);
			pedido5.setEstado(EstadosPedido.FINALIZADO.name());
			entityManager.persist(pedido5);
			ProductoPedido pp5 = new ProductoPedido();
			pp5.setPedido(pedido5);
			pp5.setYate(y1);
			pp5.setCantidad(4);
			entityManager.persist(pp5);
			
			
			
			com.ares.tiendaEjemplo.model.SetUp setup = new com.ares.tiendaEjemplo.model.SetUp();
			setup.setCompleto(true);
			entityManager.persist(setup);
		}
	
	}

}
