package com.ares.tiendaEjemplo.serviciosJPAimpl;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ares.tiendaEjemplo.constantesSQL.ConstantesSQL;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.servicios.ServicioUsuarios;

@Service
@Transactional
public class ServicioUsuariosJPAimpl implements ServicioUsuarios {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrarUsuario(Usuario u) {
        entityManager.persist(u);
    }

    @Override
    public Usuario obtenerUsuarioPorEmailyPass(String email, String pass) {
        return entityManager.createQuery("SELECT u FROM Usuario u WHERE u.email = :email AND u.pass = :pass", Usuario.class)
                .setParameter("email", email)
                .setParameter("pass", pass)
                .getSingleResult();
    }

    @Override
    public List<Usuario> obtenerUsuarios() {
        return entityManager.createQuery("SELECT u FROM Usuario u", Usuario.class).getResultList();
    }

    @Override
    public void borrarUsuario(int id) {
        Usuario u = entityManager.find(Usuario.class, id);
        if (u != null) {
            entityManager.remove(u);
        }
    }
    
    @Override
	public boolean comprobarEmailExiste(String email) {
		Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_ID_USUARIO_POR_EMAIL);
		query.setParameter("email", email);
		List<Map<String, Object>> res = com.ares.tiendaEjemplo.Utilidades.Utilidades.procesaNativeQuery(query);		
		if( res.size() > 0) {
			return true;
		}else {
			return false;
		}
	}

    @Override
    public Usuario obtenerUsuarioPorId(int id) {
        return entityManager.find(Usuario.class, id);
    }

    @Override
    public void actualizarUsuario(Usuario u) {
        entityManager.merge(u);
    }
}
