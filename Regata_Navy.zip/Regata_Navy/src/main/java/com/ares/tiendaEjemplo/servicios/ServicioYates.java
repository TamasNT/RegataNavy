package com.ares.tiendaEjemplo.servicios;

import java.util.List;
import java.util.Map;

import com.ares.tiendaEjemplo.model.Yate;

public interface ServicioYates {
	
	void registrarYate(Yate y);
	
	List<Yate> obtenerYates();
	
	List<Yate> obtenerYates(String nombre);
	
	void borrarYate(int id);
	
	Yate obtenerYatePorId(int id);
	
	Map<String, Object> obtenerYateVerDetallesPorId(int id);
	
	List <Map<String, Object>> obtenerYatesParaListado();
	
	void actualizarYate(Yate l);

}
