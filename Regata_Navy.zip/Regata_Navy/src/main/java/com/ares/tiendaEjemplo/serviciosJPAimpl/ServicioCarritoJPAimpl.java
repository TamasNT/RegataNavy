package com.ares.tiendaEjemplo.serviciosJPAimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ares.tiendaEjemplo.Utilidades.Utilidades;
import com.ares.tiendaEjemplo.constantesSQL.ConstantesSQL;
import com.ares.tiendaEjemplo.model.Carrito;
import com.ares.tiendaEjemplo.model.ProductoCarrito;
import com.ares.tiendaEjemplo.model.Usuario;
import com.ares.tiendaEjemplo.model.Yate;
import com.ares.tiendaEjemplo.servicios.ServicioCarrito;

@Service
@Transactional
public class ServicioCarritoJPAimpl implements ServicioCarrito{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void agregarProducto(int idYate, int idUsuario, int cantidad) {
		
		Usuario usuario = entityManager.find(Usuario.class, idUsuario);
		Carrito carrito = usuario.getCarrito();
		
		if(carrito == null) {
			carrito =  new Carrito();
			carrito.setUsuario(usuario);
			usuario.setCarrito(carrito);
			entityManager.persist(carrito);
		}
		
		boolean productoEnCarrito = false;
		
		for(ProductoCarrito pc : carrito.getProductoCarrito()) {
			if(pc.getYate().getId() == idYate) {
				productoEnCarrito = true;
				pc.setCantidad(pc.getCantidad() + cantidad);
				entityManager.merge(pc);
			}
		}
		
		if( ! productoEnCarrito) {
			ProductoCarrito pc = new ProductoCarrito();
			pc.setCarrito(carrito);
			pc.setYate(entityManager.find(Yate.class, idYate));
			pc.setCantidad(cantidad);
			entityManager.persist(pc);
		}
	}

	@Override
	public List<Map<String, Object>> obtenerProductosCarritoUsuario(int idUsuario) {
		
		Usuario usuario = entityManager.find(Usuario.class, idUsuario);
		Carrito carrito = usuario.getCarrito();
		
		List<Map<String, Object>> respuesta = new ArrayList<Map<String, Object>>();
		
		if (carrito != null) {
			Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_YATES_CARRITO);
			
			query.setParameter("carrito_id", carrito.getId());
			
			respuesta = Utilidades.procesaNativeQuery(query);
		}
		
		return respuesta;
	}
	
	@Override
    public void actualizarCantidadProducto(long idProducto, int idUsuario, int nuevaCantidad) {
        Usuario usuario = entityManager.find(Usuario.class, idUsuario);
        Carrito carrito = usuario.getCarrito();
        if (carrito != null) {
            for (ProductoCarrito pc : carrito.getProductoCarrito()) {
                if (pc.getYate().getId() == idProducto) {
                    pc.setCantidad(nuevaCantidad);
                    entityManager.merge(pc);
                    break;
                }
            }
        }
    }

    @Override
    public void eliminarProducto(long idProducto, int idUsuario) {
        Usuario usuario = entityManager.find(Usuario.class, idUsuario);
        Carrito carrito = usuario.getCarrito();
        if (carrito != null) {
            ProductoCarrito productoAEliminar = null;
            for (ProductoCarrito pc : carrito.getProductoCarrito()) {
                if (pc.getYate().getId() == idProducto) {
                    productoAEliminar = pc;
                    break;
                }
            }
            if (productoAEliminar != null) {
                carrito.getProductoCarrito().remove(productoAEliminar);
                entityManager.remove(productoAEliminar);
            }
        }
    }

}
