package com.ares.tiendaEjemplo.serviciosJPAimpl;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ares.tiendaEjemplo.constantesSQL.ConstantesSQL;
import com.ares.tiendaEjemplo.model.Categoria;
import com.ares.tiendaEjemplo.model.Yate;
import com.ares.tiendaEjemplo.servicios.ServicioYates;


@Service
@Transactional
public class ServicioYatesJPAimpl implements ServicioYates{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void registrarYate(Yate y) {
		Categoria c = entityManager.find(Categoria.class, y.getIdCategoria());
		y.setCategoria(c);
		entityManager.persist(y);
	}

	@Override
	public List<Yate> obtenerYates() {
		return entityManager.createQuery("Select y from Yate y").getResultList();
	}

	@Override
	public void borrarYate(int id) {
		Yate y = entityManager.find(Yate.class, id);
		entityManager.remove(y);
	}

	@Override
	public Yate obtenerYatePorId(int id) {
		return entityManager.find(Yate.class, id);
	}

	@Override
	public void actualizarYate(Yate y) {
		entityManager.merge(y);
	}

	@Override
	public Map<String, Object> obtenerYateVerDetallesPorId(int id) {
		Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_DETALLES_YATE);
		query.setParameter("id", id);
		
		NativeQueryImpl nativeQuery = (NativeQueryImpl)query;
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		
		return (Map<String, Object>) nativeQuery.getSingleResult();
	}

	@Override
	public List<Map<String, Object>> obtenerYatesParaListado() {
		Query query = entityManager.createNativeQuery(ConstantesSQL.SQL_OBTENER_LISTADO_YATES);
		
		NativeQueryImpl nativeQuery = (NativeQueryImpl)query;
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		
		return nativeQuery.getResultList();
	}

	@Override
	public List<Yate> obtenerYates(String nombre) {
		return entityManager.createQuery("Select y from Yate y where y.nombre like :nombre").setParameter("nombre", "%" + nombre + "%").getResultList();
	}
	
	

}
