package com.ares.tiendaEjemplo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Usuario {
	
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private Carrito carrito;

    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();
	
	@Id
	@GeneratedValue
	private int id;

	private String nombre;
	private String usuario;
	@Column(unique = true)
	private String email;
	private String telefono;
    private String direccion;
    private String pass;

	public Usuario(String nombre, String usuario, String email, String telefono, String direccion, String pass) {
		super();
		this.nombre = nombre;
		this.usuario = usuario;
		this.email = email;
		this.telefono = telefono;
		this.direccion = direccion;
		this.pass = pass;
	}

	public Usuario(int id, String nombre, String usuario, String email, String telefono, String direccion,
			String pass) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.usuario = usuario;
		this.email = email;
		this.telefono = telefono;
		this.direccion = direccion;
		this.pass = pass;
	}

	public Usuario(Carrito carrito) {
		super();
		this.carrito = carrito;
	}

	public Carrito getCarrito() {
		return carrito;
	}

	public void setCarrito(Carrito carrito) {
		this.carrito = carrito;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Usuario() {
	}

	public Usuario(String nombre, String email, String pass) {
		super();
		this.nombre = nombre;
		this.email = email;
		this.pass = pass;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", email=" + email + ", pass=" + pass + ", id=" + id + "]";
	}
	
}
