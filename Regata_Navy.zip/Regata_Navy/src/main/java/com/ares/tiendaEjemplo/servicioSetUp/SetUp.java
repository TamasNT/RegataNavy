package com.ares.tiendaEjemplo.servicioSetUp;

public interface SetUp {
	
	void setUp();
}
