package com.ares.tiendaEjemplo.serviciosREST;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ares.tiendaEjemplo.servicios.ServicioYates;
import com.google.gson.Gson;

@RestController
public class ServicioRESTProductos {

	@Autowired
	private ServicioYates servicioYates;
	
	@RequestMapping("obtener-productos-json")
	public ResponseEntity<String> obtenerProductosEnJSON(){
		List<Map<String, Object>> yates = servicioYates.obtenerYatesParaListado();
		String respuesta = new Gson().toJson(yates);
		return new ResponseEntity<String>(respuesta,HttpStatus.OK);
	}
	
	@RequestMapping("obtener-detalles-yate")
	public String obtenerDetallesYate(@RequestParam("id") Integer id ) {
		return new Gson().toJson(servicioYates.obtenerYateVerDetallesPorId(id));
	}
	
	
}
