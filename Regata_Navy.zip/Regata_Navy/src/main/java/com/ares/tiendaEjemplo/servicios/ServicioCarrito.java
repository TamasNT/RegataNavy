package com.ares.tiendaEjemplo.servicios;

import java.util.List;
import java.util.Map;

public interface ServicioCarrito {
	
	void agregarProducto(int idYate, int idUsuario, int cantidad);
	
	List<Map<String, Object>> obtenerProductosCarritoUsuario(int idUsuario);

	void eliminarProducto(long idProducto, int idUsuario);

	void actualizarCantidadProducto(long idProducto, int idUsuario, int nuevaCantidad);

}
