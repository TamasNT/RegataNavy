package com.ares.tiendaEjemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaEjemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
